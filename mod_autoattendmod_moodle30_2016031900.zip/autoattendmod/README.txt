//////////////////////////////////////////////////////////////////////////////////////
// Auto Attendance Module v2.1
//										by Fumi.Iseki  2013/05/07
//										mailto:iseki@solar-system.tuis.ac.jp
//										http://www.nsl.tuis.ac.jp
// 
//	This block/module are modified from Attendance block/module v1.0.8
//											by Dmitry Pupinin, Novosibirsk, Russia.


1. Overview

 This is additional module to autoattend block.
 This autoattend module is modification of the Attendance module by Mr. Dmitry Pupinin et. al.
 Please install the autoattend block before installing this module.


2. Functions

 If you use this module with autoattend block, the following functions are added to autoattend block.

 - Attendance is added to the grade.
 - Cron function works.
 - You can be used as a link attendance entry in semi-automatic mode.


3. etc.

 Please see also http://www.nsl.tuis.ac.jp/xoops/modules/xpwiki/?autoattend%20%28E%29

